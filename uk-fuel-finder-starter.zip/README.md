# UK Fuel Finder

A free, responsive starter website for comparing UK petrol and diesel prices.

## Important
The included station prices are **demo data**, not live prices. Before publishing, connect the app to a legitimate current data source.

The UK Government's Fuel Finder provides current retail fuel prices, forecourt details and timestamps. Its API requires authentication. A production version should use the official API or its permitted CSV feed, with the API credentials kept server-side rather than in browser JavaScript.

## Files
- `index.html` — website
- `style.css` — design
- `app.js` — demo data and UI logic

## Free deployment
This is a static site and can be hosted on GitHub Pages, Cloudflare Pages or Netlify.

## Production architecture
Browser -> your small backend/serverless function -> Fuel Finder API -> cached/validated results -> browser.

Do not put OAuth client secrets in `app.js`.
