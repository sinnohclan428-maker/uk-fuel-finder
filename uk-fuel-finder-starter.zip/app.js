const demo = [
 {brand:"Tesco", name:"Tesco Extra Sutton", fuel:{petrol:139.7,diesel:149.9}, distance:0.8, updated:"6 min ago", x:58,y:42},
 {brand:"Asda", name:"Asda Sutton", fuel:{petrol:140.2,diesel:150.4}, distance:1.2, updated:"11 min ago", x:30,y:60},
 {brand:"Shell", name:"Shell St Nicholas Way", fuel:{petrol:141.1,diesel:151.2}, distance:1.7, updated:"18 min ago", x:72,y:28},
 {brand:"Morrisons", name:"Morrisons Petrol Station", fuel:{petrol:141.5,diesel:150.8}, distance:2.4, updated:"9 min ago", x:44,y:75},
 {brand:"BP", name:"BP Cheam Road", fuel:{petrol:142.3,diesel:152.1}, distance:3.1, updated:"22 min ago", x:82,y:68}
];

const $=id=>document.getElementById(id);
function render(){
  const fuel=$("fuel").value;
  const sort=$("sort").value;
  let rows=[...demo].sort((a,b)=>sort==="price"?a.fuel[fuel]-b.fuel[fuel]:a.distance-b.distance);
  $("avg").textContent=(rows.reduce((s,r)=>s+r.fuel[fuel],0)/rows.length).toFixed(1)+"p";
  $("count").textContent=rows.length;
  $("refresh").textContent=new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
  $("resultText").textContent=`${rows.length} example stations · sorted by ${sort==="price"?"price":"distance"}`;
  $("results").innerHTML=rows.map((r,i)=>`
    <div class="result">
      <div class="station"><div class="logo">${r.brand[0]}</div><div><h3>${r.name}</h3><p>${r.brand} · ${r.distance} miles · updated ${r.updated}</p></div></div>
      <div class="price">${i===0?'<div class="cheap">CHEAPEST SHOWN</div>':''}<strong>${r.fuel[fuel].toFixed(1)}p</strong><span>per litre · ${fuel}</span></div>
    </div>`).join("");
  $("pins").innerHTML=rows.map((r,i)=>`<div class="pin" style="left:${r.x}%;top:${r.y}%"><i>${i+1}</i></div>`).join("");
}
$("find").onclick=()=>{ if(!$("postcode").value.trim()) { $("postcode").focus(); return; } render(); };
$("sort").onchange=render;
$("fuel").onchange=render;
$("postcode").addEventListener("keydown",e=>{if(e.key==="Enter")$("find").click()});
$("year").textContent=new Date().getFullYear();
render();